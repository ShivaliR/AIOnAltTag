(function() {
    'use strict';

    function startSetup(sliderSize, slideSize, animationDuration, autoplayInterval) {
        this.sliderSize = parseFloat(sliderSize) / 100;
        this.slideSize = parseFloat(slideSize) / 100;
        this.animationDuration = parseFloat(animationDuration);
        this.autoplayInterval = parseFloat(autoplayInterval);
      }


      function Slider(newSlider, sliderSize, slideSize, animationDuration, autoplayInterval) {
        this.startSetup = new startSetup(sliderSize, slideSize, animationDuration, autoplayInterval);
        this.wrapper = newSlider.querySelector('.wrapper');
        this.slides = Array.from(newSlider.querySelectorAll('.circular-slider .wrapper .slides-holder .slides-holder__item'));
        this.slidesSize = 0;
        this.descriptionsHolder = newSlider.querySelector('.circular-slider .wrapper .descriptions');
        this.descriptions = Array.from(newSlider.querySelectorAll('.circular-slider .wrapper .descriptions .descriptions__item'));
        this.slidesHolder = newSlider.querySelector('.circular-slider .wrapper .slides-holder');
        this.btnLeft = newSlider.querySelector('.circular-slider .wrapper .controls .controls__left');
        this.btnRight = newSlider.querySelector('.circular-slider .wrapper .controls .controls__right');
        this.btnAutoplay = newSlider.querySelector('.circular-slider .wrapper .controls .controls__autoplay');
        this.currentAngle = 0;
        this.stepAngle = 2 * Math.PI / 8; // Set step angle for 8 slides
        this.currentSlideIndex = 0; // Keep track of the current slide index
        this.slidesHolder.style.transitionDuration = this.startSetup.animationDuration + 'ms';
        this.onResize();
        this.setNav();
        this.addStyle();
        this.updateSlideVisibility(); // Initial slide visibility setup
    
        let _this = this;
        this.btnAutoplay.onclick = function() {
          if (this.classList.contains('controls__autoplay_running')) {
            this.classList.remove('controls__autoplay_running');
            this.classList.add('controls__autoplay_paused');
            clearInterval(_this.autoplay);
            _this.autoplay = null;
          } else {
            this.classList.remove('controls__autoplay_paused');
            this.classList.add('controls__autoplay_running');
            _this.setAutoplay();
          }
        };
    
        setTimeout(() => {
          _this.revealAdditionalSlides();
        }, 4000);
    
        // Set up the autoplay interval
        setInterval(function() {
          _this.rotate(-1); // Rotate to the next set of slides
        }, _this.startSetup.autoplayInterval);
      }
    

    Slider.prototype.onResize = function() {
        let radius,
            w = this.wrapper.parentNode.getBoundingClientRect().width,
            h = this.wrapper.parentNode.getBoundingClientRect().height;
        radius = ((w / 2) * this.startSetup.sliderSize / 2);
        this.setSize(Math.round(radius));
    };

    Slider.prototype.setSize = function(radius) {
        this.wrapper.style.width = 100 + '%';
        this.wrapper.style.height = 100 + '%';
        let r = 2 * radius * (1 - this.startSetup.slideSize);
        this.slidesHolder.style.width = this.slidesHolder.style.height = r + 'px';
        this.slidesRepositioning(r / 2);
        this.descriptionsHolder.style.width = (r / 2 - r * this.startSetup.slideSize + 20) * 2 + 'px';
        this.descriptionsHolder.style.height = r / 2 - r * this.startSetup.slideSize + 20 + 'px';
        this.slidesSize = Math.min(2 * radius * this.startSetup.slideSize, this.stepAngle * radius * (1 - this.startSetup.slideSize) - 50);
        this.descriptionsHolder.style.fontSize = window.innerHeight < window.innerWidth ? '1.2vh' : '1.2vw';
        for (let i = 0; i < this.slides.length; i++) {
            this.slides[i].style.width = this.slides[i].style.height = this.slidesSize + 'px';
        }
    };

    Slider.prototype.slidesRepositioning = function(r) {
        for (let i = 0; i < this.slides.length; i++) {
            let x = r * Math.cos(this.stepAngle * i + 2 * Math.PI / 2),
                y = r * Math.sin(this.stepAngle * i + 2 * Math.PI / 2);
            this.slides[i].style.transform = 'translate( ' + x + 'px, ' + y + 'px )';
        }
    };

    Slider.prototype.rotate = function(multiplier) {
        let _this = this;
        this.removeStyle();
    
        // Update the currentSlideIndex
        this.currentSlideIndex += multiplier;
        if (this.currentSlideIndex < 0) {
          this.currentSlideIndex = this.slides.length - 8;
        } else if (this.currentSlideIndex > this.slides.length - 8) {
          this.currentSlideIndex = 0;
        }
    
        this.currentAngle = -(this.stepAngle * this.currentSlideIndex * 180 / Math.PI);
        this.addStyle();
    
        // Update the slide visibility
        _this.updateSlideVisibility();
    };

    Slider.prototype.setNav = function() {
        let _this = this;
        _this.btnLeft.onclick = function() { _this.rotate(1) };
        _this.btnRight.onclick = function() { _this.rotate(-1) };
    };

    Slider.prototype.disableNav = function() {
        this.btnLeft.disabled = true;
        this.btnRight.disabled = true;
    };

    Slider.prototype.enableNav = function() {
        this.btnLeft.disabled = false;
        this.btnRight.disabled = false;
    };

    Slider.prototype.addStyle = function() {
        for (let i = 0; i < this.slides.length; i++) {
            if (i >= this.currentSlide && i < this.currentSlide + 8) {
                this.slides[i].classList.add('slide__active');
                this.descriptions[i].classList.add('description__active');
            }
        }
    };
    Slider.prototype.updateSlideVisibility = function() {
        // Remove slide-leaving and slide-entering classes from all slides
        for (let i = 0; i < this.slides.length; i++) {
          this.slides[i].classList.remove('slide-leaving', 'slide-entering');
        }
    
        // Show only the 8 slides starting from the currentSlideIndex
        for (let i = 0; i < this.slides.length; i++) {
          this.slides[i].style.display = 'none';
        }
        for (let i = this.currentSlideIndex; i < this.currentSlideIndex + 8; i++) {
          const slideIndex = i % this.slides.length;
          this.slides[slideIndex].style.display = 'flex';
        }
    
        // Add slide-leaving class to the 3 slides that are leaving
        for (let i = this.currentSlideIndex - 3; i < this.currentSlideIndex; i++) {
          const slideIndex = i < 0 ? this.slides.length + i : i;
          this.slides[slideIndex].classList.remove('slide-entering');
          this.slides[slideIndex].classList.add('slide-leaving');
        //   this.slides[slideIndex].style.display = 'none';
        }
    
        // Add slide-entering class to the 3 slides that are entering
        for (let i = this.currentSlideIndex + 8; i < this.currentSlideIndex + 11; i++) {
          const slideIndex = i >= this.slides.length ? i - this.slides.length : i;
          this.slides[slideIndex].classList.remove('slide-leaving');
          this.slides[slideIndex].classList.add('slide-entering');
        //   this.slides[slideIndex].style.display = 'flex';
        }
    };
    
    Slider.prototype.removeStyle = function() {
        for (let i = 0; i < this.slides.length; i++) {
            this.slides[i].classList.remove('slide__active');
            this.descriptions[i].classList.remove('description__active');
        }
    };

    Slider.prototype.revealAdditionalSlides = function() {
        for (let i = 8; i < this.slides.length; i++) {
            this.slides[i].classList.add('slide__active');
            this.descriptions[i].classList.add('description__active');
        }
    };

    window.circularSlider2 = new Slider(document.querySelector('.circular-slider-2'), 100, 50, 800, 1000);
})();
 